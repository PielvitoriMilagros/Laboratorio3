var x;

function foo(a,b,c){
    console.log(arguments.length);
}

x=foo;

x(23,12);