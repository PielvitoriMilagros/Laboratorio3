/// <reference path="hello.ts" />

let msj:string;
msj = "GoodBye";
console.log(msj);

